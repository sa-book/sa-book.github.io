# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))

# adjusted version of the legend function
source(here("source", "legend_large_box.R"))

# load environment generated in "2-0_ChapterSetup.R"
load(here("data", "R", "2-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Preparatory work required for rendering the plot ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Define color palette
colspace.partner <- sequential_hcl(4, palette = "Heat", rev = TRUE)


# Adjust legend to accommodate additional information (Entropy)
col.legend <- c(colspace.partner, "white")
lab.legend <- c(longlab.partner, "Entropy")
bcol.legend <- c(rep("black",4), "white")


# Extract Entropy for each sex 
# (will be appear as additional line in the state distribution plot)
aux1 <- seqstatd(partner.month.seq[family$sex==1,])$Entropy
aux0 <- seqstatd(partner.month.seq[family$sex==0,])$Entropy


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 2.4 - State distribution plot + Entropy (colored) ----
# side-by-side: Women vs Men
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

cairo_pdf(here("figures", "2-4-2_Fig2-4_DplotEntropy_color.pdf"),
          width=10,
          height=6.5)

layout.fig1 <- layout(matrix(c(1,2,3,3), 2, 2, byrow = TRUE),
                      heights = c(.75,.25))
layout.show(layout.fig1)

par(mar = c(2, 4, 2, 4) + 0.1, las = 1, 
    mgp=c(2.7,1,-.5))
seqdplot(partner.month.seq[family$sex==1,], ylab = "Relative frequency / Entropy",
         with.legend = "FALSE", border = NA, axes = FALSE,
         cpal = colspace.partner)
text(10,.06, "Women", cex = 2, adj = c(0,.5))
lines(aux1, col = "black", lwd = 2, lty = 2)

par(mgp=c(3,1,0.25))
axis(1, at=(seq(0,264, by = 24)), labels = seq(18,40, by = 2))
mtext(text = "Age", cex = .8,
      side = 1,#side 1 = bottom
      line = 2.5)

par(mar = c(2, 4, 2, 4) + 0.1, las = 1, 
    mgp=c(2.7,1,-.5))

seqdplot(partner.month.seq[family$sex==0,], ylab = "Relative frequency / Entropy",
         with.legend = "FALSE", border = NA, axes = FALSE,
         cpal = colspace.partner)
text(10,.06, "Men", cex = 2, adj = c(0,.5))
lines(aux0, col = "black", lwd = 2, lty = 2)

par(mgp=c(3,1,0.25))
axis(1, at=(seq(0,264, by = 24)), labels = seq(18,40, by = 2))
mtext(text = "Age", cex = .8,
      side = 1,#side 1 = bottom
      line = 2.5)


par(mar=c(0, 1, 0, 1))
plot(NULL ,xaxt='n',yaxt='n',bty='n',ylab='',xlab='', xlim=0:1, ylim=0:1)

# Alternative specification of legend (using tweaked version of legend)
legend_large_box("center", legend = lab.legend,
                 ncol=3, fill=col.legend,
                 lty=c(rep(0,4),2), border = bcol.legend,
                 box.cex=c(4.5,1.5),  y.intersp=2,
                 inset=c(0,-.4), xpd=TRUE)

dev.off()

pdf_convert(here("figures", "2-4-2_Fig2-4_DplotEntropy_color.pdf"),
            format = "png", dpi = 289, pages = 1, antialias = TRUE,
            here("figures", "2-4-2_Fig2-4_DplotEntropy_color.png"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
