# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())


# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)


# (down)load required packages using pacman
source(here("source", "LoadInstallPackages.R"))


# load environment generated in "6-0_ChapterSetup.R"
load(here("data", "R", "6-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Defining groups for comparison ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Note:
#   - For our example we focus on the following grouping variables:
#         - East vs West
#         - Women vs men
#         - low vs high education 
#   - First, we create a list indicating the group members for the following
#     analysis; the list will be used to subset the distance matrix or the
#     main data created in "6-0_ChapterSetup.R"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# List: Comparison groups for discrepancy analysis


# Note:
#   Grouping variables: (I) Region (East vs West) and (II) gender (men vs women)
#   (I) Region:
#     (1) Total difference
#       (1.1) Men
#       (1.2) Women
#   (II) Gender:
#     (1) Total difference
#       (1.1) West
#       (1.2) East
#     (2) No highschool
#       (2.1) West
#       (2.2) East
#     (3) Highschool
#       (3.1) West
#       (3.2) East
# 
#   We generate a separate sub-list for comparisons by region and for those
#   by gender because both will require different grouping variables when
#   calling "dissassoc"

group.idx <- list(region = NULL, gender = NULL)

group.idx$region <- list(total = rep(TRUE, nrow(activity)),
                         men = activity$sex==0,
                         women = activity$sex==1)

group.idx$gender <- list(total = rep(TRUE, nrow(activity)),
                         west = activity$east==0,
                         east = activity$east==1,
                         lowedu = activity$highschool == 0,
                         lowedu.w = (activity$highschool == 0 & 
                                       activity$east==0),
                         lowedu.e = (activity$highschool == 0 & 
                                       activity$east==1),
                         hiwedu = activity$highschool == 1,
                         hiedu.w = (activity$highschool == 1 & 
                                      activity$east==0),
                         hiedu.e = (activity$highschool == 1 & 
                                      activity$east==1))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Discrepancy analysis and Levene Tests ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# Run discrepancy analysis to test differences by region [group = activity$east]
discr.region <- map(group.idx$region,
                    ~dissassoc(activity.year.om[.,.], group = activity$east[.]))


# Run discrepancy analysis to test differences by gender [group = activity$sex]
discr.gender <- map(group.idx$gender,
                    ~dissassoc(activity.year.om[.,.], group = activity$sex[.]))


# Combine the resulting list
discr.complete <- c(discr.region, discr.gender)

# unique names for list elements
names(discr.complete) <- c(paste0("reg.",names(discr.region)),
                            paste0("sex.",names(discr.gender)))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Pseudo R2 + corresponding p-values 


# extract information from the "discrepancy list" named "levene.complete"
pseudoR2 <- bind_cols(bind_rows(map(discr.complete,~(.$stat[3,]))),
                      N = as.integer(map(discr.complete,~(.$groups[3,1])))) %>%
  set_rownames(c("Overall", "Men", "Women", "Overall ", "West", "East",
                 "No highschool degree", "West ", "East ", 
                 "Highschool degree", "West  ", "East  "))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# BIC & Likelihood Ratio Test ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Calculate BICs and LRTs  to test differences by region [group = activity$east]
bic.region <- map(group.idx$region,
                  ~seqCompare(activity.year.seq[.,], group = activity$east[.],
                              method="OM", sm="CONSTANT"))


# Calculate BICs and LRTs to test differences by gender [group = activity$sex]
bic.gender <- map(group.idx$gender,
                  ~seqCompare(activity.year.seq[.,], group = activity$sex[.],
                              method="OM", sm="CONSTANT"))


# Combine the resulting list
bic.complete <- c(bic.region, bic.gender)

# Better row names
names(bic.complete) <- c(paste0("reg.",names(discr.region)),
                         paste0("sex.",names(discr.gender)))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Extract the information required for the table into a data frame
bic <- t(bind_rows(map(bic.complete,~(.[c(3,1,2)])))) %>%
  as.data.frame() %>%
  rename(`BIC diff.` = 1, LRT = 2, `p-value` = 3) %>%
  bind_cols(N = as.integer(map(discr.complete,~(.$groups[3,1])))) %>%
  set_rownames(c("Overall", "Men", "Women", "Overall ", "West", "East",
                 "No highschool degree", "West ", "East ", 
                 "Highschool degree", "West  ", "East  "))
  

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Combined BIC & Pseudo-R2: Table 6.4 ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Join tables and store them in new data frame
bic.pseudoR2 <- bic %>%
  select(!LRT) %>%
  mutate(`pseudo-R2 ` = pseudoR2[1],
         `p-value ` = pseudoR2[2], .before = N) %>%
  as.matrix() %>%
  set_rownames(c("Overall", "Men", "Women", "Overall", "West", "East",
                 "No highschool degree", "West", "East", 
                 "Highschool degree", "West", "East"))   


# alternative to set_rownames for data frames: 
# `rownames<-`(c(...))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# The table
bic.pseudoR2 %>%
  kbl(digits = c(2,3,2,3), align = c("r", rep("c", 3), "r")) %>%
  row_spec(0, italic = T) %>%
  kable_styling(full_width = F)  %>%
  pack_rows("West vs East", 1, 3, indent = F) %>%
  pack_rows("Men vs Women", 4, 12, indent = F) %>%
  add_indent(c(2,3,5,6,8, 9, 11, 12)) %>%
  add_header_above(c(" " = 2, 
                     "Likelihood Ratio Test" = 1, 
                     "Discrepancy Analysis" = 2, " " = 1))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
