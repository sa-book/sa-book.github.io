# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())


# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)


# install (if necessary) and load required packages using pacman
source(here("source", "LoadInstallPackages.R"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~
# Import data ----
# ~~~~~~~~~~~~~~~~

# import Stata data sets using haven 
family    <- read_dta(here("data", "Stata", "PartnerBirthbio.dta"))
activity  <- read_dta(here("data", "Stata", "Activitybio.dta"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Extracting and recoding sequence variables ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# family biographies
seqvars.partner.child <- family %>%
  select(starts_with("state"))


# activity biographies
seqvars.activity <- activity %>%
  select(starts_with("state"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Define labels for different alphabets ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# full state space - partner & birth bio

shortlab.partner.child <- c("S", "Sc", 
                            "LAT", "LATc", 
                            "COH", "COHc",
                            "MAR", "MARc1", "MARc2+")

longlab.partner.child <- names(attributes(seqvars.partner.child$state1)$labels)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# full state space - partner & birth bio

shortlab.activity <- c("EDU", "MIL/CS",
                       "PT", "FT", "SELF",
                       "PLEAVE", "MARGINAL", "UNEMP")

longlab.activity <- names(attributes(seqvars.activity$state1)$labels)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Define different color palettes ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Family colors
col1 <- sequential_hcl(5, palette = "Blues")[3:2]   # Single states
col2 <- sequential_hcl(5, palette = "Greens")[2:1]  # LAT states
col3 <- sequential_hcl(5, palette = "Oranges")[3:2] # Cohabitation states
col4 <- sequential_hcl(5, palette = "magenta")[3:1] # Married states

# Combine to full color palette
colspace.partner.child <- c(col1, col2, col3, col4)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Activity colors
col1 <- sequential_hcl(5, palette = "Burg", rev = TRUE)[c(2,4)]
col2 <- sequential_hcl(8, palette = "ag_GrnYl", rev = T)[c(4,6,8,2)]
col3 <- sequential_hcl(5, palette = "Heat")[3:2]

# Combine to full color palette
colspace.activity <- c(col1, col2, col3)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Defining sequence objects ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# monthly data...

# family bio
partner.child.month.seq <- seqdef(seqvars.partner.child,
                                  states = shortlab.partner.child,
                                  labels = longlab.partner.child, 
                                  alphabet = c(1:9),
                                  cpal = colspace.partner.child,
                                  weights = family$weight40,
                                  id = family$id,
                                  xtstep = 24)


# activity bio
activity.month.seq <- seqdef(seqvars.activity,
                             states = shortlab.activity,
                             labels = longlab.activity, 
                             alphabet = c(1:8),
                             cpal = colspace.activity,
                             weights = activity$weight40,
                             id = activity$id,
                             xtstep = 24)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# change granularity --> years instead of months (using modal values)


# family bio
partner.child.year.seq <- seqgranularity(partner.child.month.seq,
                                          tspan=12, method="mostfreq")


# activity bio
activity.year.seq <- seqgranularity(activity.month.seq,
                                    tspan=12, method="mostfreq")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Compute OM distance matrices required for discrepancy analysis ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


partner.child.year.om <- seqdist(partner.child.year.seq,
                                 method="OM", sm= "CONSTANT")


activity.year.om <- seqdist(activity.year.seq, method="OM", sm= "CONSTANT")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

save.image(here("data", "R", "6-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~