# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())


# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)


# (down)load required packages using pacman
source(here("source", "LoadInstallPackages.R"))


# load environment generated in "6-0_ChapterSetup.R"
load(here("data", "R", "6-0_ChapterSetup.RData"))


# GraphViz has to be installed to produce a regression tree with
# `seqtreedisplay` --> https://graphviz.org/
# Although `seqtreedisplay` might automatically find the correct installation 
# path of GraphViz on your machine, we explicitly specify the path here. 
# Please adjust to tell R where to find GraphViz on your computer.

graphviz.dir <- "C:/Program Files/GraphViz"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~
# Simplified alphabet ----
# ~~~~~~~~~~~~~~~~~~~~~~~~

# For our example in the book we use a reduced alphabet
# Here we recode the original alphabet and adjust the labels and
# color palette accordingly


alphabet(activity.year.seq)


activity.year.seq2 <- seqrecode(activity.year.seq,
                                recodes = list("EDU" = "EDU", 
                                               "PT" = "PT",
                                               "FT" = c("FT", "SELF"),
                                               "PLEAVE" = "PLEAVE",
                                               "OTHER" = c("MIL/CS","MARGINAL", "UNEMP")))

longlab.activity2 <- c("education", "part-time", "full-time", 
                       "parental leave", "other")

# adjust color attribute (to gray) to ensure correct legend in seqtree
attributes(activity.year.seq2)$cpal <- brewer.pal(5, "Greys")

# specify revised labels for new alphabet to ensure correct legend in seqtree
attributes(activity.year.seq2)$labels <- longlab.activity2


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Run regression tree analysis and plot results (Figure 6.1) ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# Compute dissimilarity matrix required as 
# input for regression tree analysis
activity.year.om2 <- seqdist(activity.year.seq2, 
                             method="OM", sm= "CONSTANT")


# Run regression tree analysis
activitytree <- seqtree(activity.year.seq2 ~ east + sex + highschool,
                        data = activity, diss = activity.year.om2,
                        weighted = F, max.depth = 3)


# Plot the results and save the figure
seqtreedisplay(activitytree, type = "d",
               cex.main = 2.5,
               with.legend=T,
               gvpath = graphviz.dir,
               filename = here("figures", "Figure_6-1_Tree.png"))

seqtreedisplay(activitytree, type = "d",
               cex.main = 2.5,
               with.legend=T,
               gvpath = graphviz.dir,
               device.args=list(width=480*300/72, height=480*300/72, res=300),
               filename = here("figures", "Figure_6-1_Tree.png"))


# Convert png to pdf
fig.6.1 <- image_read(here("figures", "Figure_6-1_Tree.png"))

image_write(fig.6.1, format = "pdf", 
            here("figures", "Figure_6-1_Tree.pdf"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
