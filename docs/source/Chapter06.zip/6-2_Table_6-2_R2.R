# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())


# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)


# (down)load required packages using pacman
source(here("source", "LoadInstallPackages.R"))


# load environment generated in "6-0_ChapterSetup.R"
load(here("data", "R", "6-0_ChapterSetup.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ======================================================
# Write little function `R2discr` to extract Pseudo R2s 
# and corresponding p-values for selected groups
# ======================================================


# Note:
# This function/script only works if the TraMineR function `dissassoc`   
# stores its results in the same way as it did when we wrote this code
# (TraMineR version 2.2.3) because we are extracting several results for 
# producing our tables. For instance, `.$stat[3,]`is extracting the 
# Pseudo R2



R2discr <- function(rawdata,diss){
#Grouping variables: region, sex, education
group.idx <- list(Region = rawdata$east,
                  Gender = rawdata$sex,
                  "Highschool degree" = rawdata$highschool)

#run discrepancy analysis for each subgroup 
discrepancies <- map(group.idx,~dissassoc(diss, group = .))

#Extract Pseudo R2s and corresponding p-values 
R2p2 <- map_dfr(discrepancies,
                      ~.$stat[3,]) %>%
  as.data.frame() %>%
  mutate(t0 = round(t0,2)) %>%
  rename(R2 = t0) %>%
  set_rownames(names(group.idx))

return(R2p2)
}

# ==============================================================================
# ==============================================================================

# ==================================================
# Apply function to yearly activity and family bios
# ==================================================

r2p.family <- R2discr(family,partner.child.year.om)
r2p.activity <- R2discr(activity,activity.year.om)

names(r2p.family) <- paste0("fam.",names(r2p.activity))
names(r2p.activity) <- paste0("act.",names(r2p.activity))


# ==============================================================================
# ==============================================================================

# ===============================================
# Multi-factor ANOVA from a dissimilarity matrix
# activity bio only
# ===============================================

mfac <- dissmfacw(activity.year.om ~ east + sex + highschool,
                  data = activity)


mfac_r2 <- tail(mfac$mfac[,3:4],1)
mfac <- mfac$mfac[1:3, 3:4]
mfac[1] <- round(mfac[1],2)
mfac[2] <- round(mfac[2],3)

# ==============================================================================
# ==============================================================================

# generate dataset for kable
kbldata <- bind_cols(r2p.family, r2p.activity, mfac) %>%
  set_colnames(c("$R^2$", "p-value","$R^2$", "p-value",
                 "$\\Delta R^2$ ", "p-value")) 


digits <- function(x,y) trimws(format(round(x, y), nsmall=y))


kbldata <- bind_cols(r2p.family, r2p.activity, mfac) %>%
  mutate(across(contains("R2"), ~digits(.,2))) %>%
  mutate(across(contains("value"), ~digits(.,3))) %>%
  set_rownames(rownames(r2p.family)) %>%
  rbind(" " = c(rep("",4), "$R^2_{total}$", "" )) %>%
  rbind(Total = c(rep("",4),digits(mfac_r2[[1]],2),digits(mfac_r2[[2]],3))) 
  

# ==============================================================================
# ==============================================================================

# Produce the table
kbl(kbldata,
    col.names = c("$R^2$", "p-value","$R^2$", "p-value",
                  "$\\Delta R^2$ ", "p-value"),
    align = "c") %>%
  kable_styling(full_width = F) %>%
  add_header_above(c(" ", 
                     "Family sequence\n(bivariate)" = 2,
                     "Activity sequence\n(bivariate)" = 2,
                     "Activity sequence\n(multivariate)" = 2)) 
  

# ==============================================================================
# ==============================================================================

