# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# In this script we define a function that allows us to produce results
# as those which shown in Table 6.1 for all sequence data and corresponding 
# source data that contain the grouping binary variables "east", "sex", 
# and "highschool". This function is tailor-made for our specific data, but
# the general setup could be applied to other data by adjusting it accordingly.

# Note:
# This function only works if the TraMineR functions `dissassoc` & `seqici` 
# store their results in the same way as they did it when we wrote this code
# (TraMineR version 2.2.3) because we are extracting several results for 
# producing our tables. For instance `.$groups$n[1:2]`is extracting the case
# numbers of the two groups compared in a discrepancy analysis using `dissassoc` 

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


DiscrCompTest <- function(rawdata,seqdata,diss) {

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Extract discrepancies, group sizes, and p-values for selected groups ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# Grouping variables: region, sex, education
group.idx <- list(region = rawdata$east,
                  sex = rawdata$sex,
                  highschool = rawdata$highschool)


# Run discrepancy analysis for each subgroup 
discrepancies <- map(group.idx,
                     ~dissassoc(diss, group = .))


# Extract N
gr.n <- map(discrepancies,
            ~.$groups$n[1:2]) %>% 
  unlist %>%
  as.data.frame() %>% 
  t() %>%
  set_rownames("N")


# Extract discrepancies
gr.discr <- map(discrepancies,
                ~.$groups$discrepancy[1:2]) %>%
  unlist  %>%
  as.data.frame() %>% 
  t() %>%
  set_rownames("Discrepancy")


# Extract p-values from Levene-Test
levene <- map_dfc(discrepancies,
                  ~.$stat[5,2]) %>%
  as.data.frame() %>%
  set_rownames("Levene Test - p-value")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Compute complexities and p-values (t-test) for selected groups ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# Grouping variables: region, sex, education
group.idx <- list(west = rawdata$east == 0, 
                  east = rawdata$east == 1,
                  men = rawdata$sex == 0,
                  women = rawdata$sex == 1,
                  noabi = rawdata$highschool == 0,
                  abi = rawdata$highschool == 1)


# Group specific averages of complexity
gr.complex <- map(group.idx,
                  ~mean(seqici(seqdata[.,]))) %>%
  unlist() %>%
  as.data.frame() %>%
  t() %>%
  set_rownames("Complexity")


# Run t-test on complexity pairs (e.g. east vs. west)

# Complexity vector for each sub-group
complexities <- map(group.idx,
                    ~seqici(seqdata[.,]))


# Vector referencing the first group of each group comparison
comparisons <- as.numeric(1:length(group.idx))[1:length(group.idx) %% 2 == 1]


# Helper function for obtaining p-values with 3 digits (as string)
dig3 <- function(x) trimws(format(round(x, 3), nsmall=3))


# Run t-tests and store the p-values as data frame 
pvalues <- map(comparisons,
               ~dig3(t.test(complexities[[.]],complexities[[.+1]])$p.value)) %>%
  rbind() %>%
  as.data.frame() %>%
  set_rownames("t-Test - p-value")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Combine the different results and print table using kable ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Combine case numbers, discrepancies, and complexities
DiscrComplex <- rbind(as.character(gr.n),
                      as.character(round(gr.discr,2)),
                      as.character(round(gr.complex,2))) %>%
  as.data.frame()


# Add meaningful column names  
colnames(DiscrComplex) <- colnames(gr.n)  


# Add p-values in the right positions for table  
DiscrComplex %<>%
  mutate(`p-value` = c("",levene[1,1],pvalues[1,1]), .after = region2) %>%
  mutate(` p-value` = c("",levene[1,2],pvalues[1,2]), .after = sex2) %>%
  mutate(`  p-value` = c("",levene[1,3],pvalues[1,3]), .after = highschool2) %>%
  set_rownames(c("N", "Discrepancy", "Complexity"))


# whitespaces are added to names that otherwise would appear multiple times
# (doublettes would result ins error message..)
colnames(DiscrComplex) <- c("West", "East", "p-value",
                            "Men", "Women", " p-value",
                            "No", "Yes",  "  p-value")


# Setting the stage for kable: add footnote markers
names(DiscrComplex)[3] <- paste0(names(DiscrComplex)[3], 
                                 footnote_marker_number(1))


names(DiscrComplex)[6] <- paste0(names(DiscrComplex)[6], 
                                 footnote_marker_number(1))


names(DiscrComplex)[9] <- paste0(names(DiscrComplex)[9], 
                                 footnote_marker_number(1))


# Produce the table
out <- kbl(DiscrComplex, escape = F) %>%
  kable_styling(full_width = F) %>%
  add_header_above(c(" " = 1, 
                     "Region" = 3,
                     "Gender" = 3,
                     "Highschool degree" = 3)) %>%
  footnote(number = c("Discrepancy: Levene Test, Complexity: t-Test"))


return(out)

}

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
