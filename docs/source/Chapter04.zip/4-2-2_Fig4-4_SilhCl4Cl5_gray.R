# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))

# load environment generated in "4-0_ChapterSetup.R"
load(here("data", "R", "4-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Preparatory work required for rendering the plot ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Use Ward-linkage as starting clustering

fam.ward1 <- hclust(as.dist(partner.child.year.om), 
                    method = "ward.D", 
                    members = family$weight40)

# Compute wcKMedoids clustering (PAM) for different number of clusters

fam.pam.ward <- wcKMedRange(partner.child.year.om, 
                            weights = family$weight40, 
                            kvals = 2:10,
                            initialclust = fam.ward1)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Extract the 4-cluster solution

fam.pam.ward.4cl<-fam.pam.ward$clustering$cluster4

# Tabulate the 4-cluster solution 

table(fam.pam.ward.4cl)

# Attach the vector with the 4-cluster solution to the main data.frame

family$fam.pam.ward.4cl<-fam.pam.ward.4cl

# Re-label the 4 clusters from 1 to 4 instead of the medoid id number

family$fam.pam.ward.4cl<-car::recode(family$fam.pam.ward.4cl, "1532=1; 1664=2; 1643=3; 985=4")

# Compute the AWS silhouette by cluster

silh.pam.ward.4cl <- silhouette(family$fam.pam.ward.4cl, dmatrix = partner.child.year.om)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Extract the 5-cluster solution

fam.pam.ward.5cl<-fam.pam.ward$clustering$cluster5

# Tabulate the 5-cluster solution 

table(fam.pam.ward.5cl)

# Attach the vector with the 5-cluster solution to the main data.frame

family$fam.pam.ward.5cl<-fam.pam.ward.5cl

# Re-label the 5 clusters from 1 to 5 instead of the medoid id number

family$fam.pam.ward.5cl<-car::recode(family$fam.pam.ward.5cl, "982=1; 790=2; 373=3; 1643=4; 985=5")

# Compute the AWS silhouette by cluster

silh.pam.ward.5cl <- silhouette(family$fam.pam.ward.5cl, dmatrix = partner.child.year.om)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 4.4-a - Silhouette 4-cluster solution ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

cairo_pdf(here::here("figures", "4-2-2_Fig4-4_SilhCl4Cl5_a_gray.pdf"),
          width=8,
          height=10)

plot(silh.pam.ward.4cl, main = "Silhouette PAM+Ward solution", col="grey", border=NA)

dev.off()

pdf_convert(here::here("figures", "4-2-2_Fig4-4_SilhCl4Cl5_a_gray.pdf"),
            format = "png", dpi = 300, pages = 1,
            here::here("figures", "4-2-2_Fig4-4_SilhCl4Cl5_a_gray.png"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 4.4-b - Silhouette 5-cluster solution ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

cairo_pdf(here::here("figures","4-2-2_Fig4-4_SilhCl4Cl5_b_gray.pdf"),
          width=8,
          height=10)

plot(silh.pam.ward.5cl, main = "Silhouette PAM+Ward solution", col="grey", border=NA)

dev.off()

pdf_convert(here::here("figures", "4-2-2_Fig4-4_SilhCl4Cl5_b_gray.pdf"),
            format = "png", dpi = 300, pages = 1,
            here::here("figures", "4-2-2_Fig4-4_SilhCl4Cl5_b_gray.png"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 4.4  - Combined Silhouette 4 and 5-cluster solution ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

pdf(here::here("figures", "4-2-2_Fig4-4_SilhCl4Cl5_gray.pdf"),
          width=14,
          height=8)

par(mfrow=c(1,2))
plot(silh.pam.ward.4cl, main = "(a) four-cluster solution", col="grey", border=NA)
plot(silh.pam.ward.5cl, main = "(b) five-cluster solution", col="grey", border=NA)

dev.off()

pdf_convert(here::here("figures", "4-2-2_Fig4-4_SilhCl4Cl5_gray.pdf"),
            format = "png", dpi = 300, pages = 1,
            here::here("figures", "4-2-2_Fig4-4_SilhCl4Cl5_gray.png"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#save.image(here("data", "R", "yourfinlename.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
