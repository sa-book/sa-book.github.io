# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))

# load environment generated in "4-0_ChapterSetup.R"
load(here("data", "R", "4-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Preparatory work yearly data ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Hierarchical cluster analysis, non-squared dissimilarities, weighted

fam.ward1 <- hclust(as.dist(partner.child.year.om), 
                    method = "ward.D", 
                    members = family$weight40)

# PAM cluster analysis, weighted

fam.pam <- wcKMedRange(partner.child.year.om, 
                       weights = family$weight40, 
                       kvals=2:10)

# PAM cluster analysis initialized with Ward, weighted

fam.pam.ward <- wcKMedRange(partner.child.year.om, 
                            weights = family$weight40, 
                            kvals = 2:10,
                            initialclust = fam.ward1)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Extract the 4-cluster solution

fam.pam.ward.4cl<-fam.pam.ward$clustering$cluster4

# Attach the vector with the 4-cluster solution to the main data.frame

family$fam.pam.ward.4cl<-fam.pam.ward.4cl

# Re-label clusters from 1 to 4 instead of medoid id

family$fam.pam.ward.4cl<-car::recode(family$fam.pam.ward.4cl, "1532=1; 1664=2; 1643=3; 985=4")

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Extract the 5-cluster solution

fam.pam.ward.5cl<-fam.pam.ward$clustering$cluster5

# Attach the vector with the 5-cluster solution to the main data.frame

family$fam.pam.ward.5cl<-fam.pam.ward.5cl

# Re-label clusters from 1 to 5 instead of medoid id

family$fam.pam.ward.5cl<-car::recode(family$fam.pam.ward.5cl, "982=1; 790=2; 373=3; 1643=4; 985=5")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Preparatory work monthly data ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Hierarchical cluster analysis, non-squared dissimilarities, weighted

fam.ward1.month <- hclust(as.dist(partner.child.month.om), 
                          method = "ward.D", 
                          members = family$weight40)

# PAM cluster analysis initialized with Ward, weighted

fam.pam.ward.month <- wcKMedRange(partner.child.month.om, 
                                  weights = family$weight40, 
                                  kvals = 2:10,
                                  initialclust = fam.ward1.month)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Extract the 5-cluster solution

fam.pam.ward.month.5cl<-fam.pam.ward.month$clustering$cluster5

# Attach the vector with the 5-cluster solution to the main data.frame

family$fam.pam.ward.month.5cl<-fam.pam.ward.month.5cl

# Re-label clusters from 1 to 5 instead of medoid id

family$fam.pam.ward.month.5cl<-car::recode(family$fam.pam.ward.month.5cl, "1652=1; 1032=2; 412=3; 869=4; 927=5")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Table 4.5 - Cluster quality criteria for PAM clustering  ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Print part (a) of the table

fam.pam.stats

# Export part (a) of the table as .csv

fam.pam.stats<-data.frame(fam.pam["stats"])

write.csv(fam.pam.stats, (here("tables", "Chapter4-2-2_Tab4-5a.csv")))

# Print part (b) of the table

fam.pam.ward.stats

# Export part (b) of the table as .csv

fam.pam.ward.stats<-data.frame(fam.pam.ward["stats"])

write.csv(fam.pam.ward.stats, (here("tables", "Chapter4-2-2_Tab4-5b.csv")))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Table 4.6 - Comparison between 4 and 5-cluster solutions for PAM+Ward clustering  ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

comp.pam.ward<-table(family$fam.pam.ward.5cl, family$fam.pam.ward.4cl)

# Print the table

comp.pam.ward

# Export the table as a .cvs file

write.csv(comp.pam.ward,(here("tables", "Chapter4-2-1_Tab4-6.csv")))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Table 4.7 - Comparison between yearly and monthly data, 5 clusters PAM+Ward  ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

comp.y.m<-table(family$fam.pam.ward.5cl, family$fam.pam.ward.month.5cl)

# Print the table

comp.y.m

# Export the table as a .cvs file

write.csv(comp.y.m,(here("tables", "Chapter4-2-1_Tab4-7.csv")))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~
# Bonus code ----
# ~~~~~~~~~~~~~~~

#print the quality test for different cluster solutions
fam.pam.stats<-data.frame(fam.pam["stats"])
write.csv(fam.pam.stats, "rChapter4-1_CQI_pam.csv")


png(file = "rChapter4-1_CQI_pam.png", width = 2000, height = 2000, pointsize = 50) #saving format
plot(fam.pam, lwd = 4)
dev.off()

png(file = "rChapter4-1_CQI_zscore_pam.png", width = 2000, height = 2000, pointsize = 50) #saving format
plot(fam.pam, norm = "zscore", lwd = 4)
dev.off()

plot(fam.pam, stat = c("ASW", "HC", "PBC"), norm = "zscore", lwd = 4)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#save.image(here("data", "R", "yourfinlename.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

