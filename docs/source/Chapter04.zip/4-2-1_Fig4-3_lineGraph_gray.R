# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))


# load environment generated in "4-0_ChapterSetup.R"
load(here("data", "R", "4-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 4.3 - "Elbow"/line graph ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Hierarchical clustering algorithm, Ward-linkage, nonsquared dissimilarities 

cairo_pdf(here::here("figures", "4-2-1_Fig4-3_lineGraph_gray.pdf"),
          width=7,
          height=7)

fviz_nbclust(partner.child.year.om, FUN = hcut, method = "wss",
             barfill = "black",
             barcolor = "black",
             linecolor = "black")
dev.off()

pdf_convert(here::here("figures", "4-2-1_Fig4-3_lineGraph_gray.pdf"),
            format = "png", dpi = 300, pages = 1,
            here::here("figures", "4-2-1_Fig4-3_lineGraph_gray.png"))

