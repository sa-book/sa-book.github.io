# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))

# only left for seqplot.rf
source(here("source", "rfplotsleft.R"))

# load environment generated in "4-0_ChapterSetup.R"
load(here("data", "R", "4-0_ChapterSetup.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Preparatory work required for rendering the plot ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Use Ward-linkage as starting clustering

fam.ward1 <- hclust(as.dist(partner.child.year.om), 
                    method = "ward.D", 
                    members = family$weight40)

# Compute wcKMedoids clustering (PAM) for different number of clusters

fam.pam.ward <- wcKMedRange(partner.child.year.om, 
                            weights = family$weight40, 
                            kvals = 2:10,
                            initialclust = fam.ward1)

# Extract the 5-cluster solution

fam.pam.ward.5cl<-fam.pam.ward$clustering$cluster5

# Tabulate the 5-cluster solution 

table(fam.pam.ward.5cl)

# Attach the vector with the 5-cluster solution to the main data.frame

family$fam.pam.ward.5cl<-fam.pam.ward.5cl

# Re-label the 5 clusters from 1 to 5 instead of the medoid id number

family$fam.pam.ward.5cl<-car::recode(family$fam.pam.ward.5cl, "982=1; 790=2; 373=3; 1643=4; 985=5")

# Compute the AWS silhouette by cluster

silh.pam.ward.5cl <- silhouette(family$fam.pam.ward.5cl, dmatrix = partner.child.year.om)

# Generate a vector with the Silhoutte values

sil.width.pam.ward.5cl<-as.vector(silh.pam.ward.5cl[,3])

# Create labels for the clusters

fam.pam.ward.lab.5cl <- c("Early parenthood in cohabitation", 
                          "LAT and long-lasting cohabitation without children",
                          "Early marriage with 1 child", 
                          "Long-lasting singleness and childlessness", 
                          "Early marriage with 2+ children")

fam.pam.ward.factor.5cl <- factor(family$fam.pam.ward.5cl, levels = c(1,2,3,4,5), 
                                  labels=fam.pam.ward.lab.5cl)

# Attach the cluster-vector (with labels) to the main data.frame

family$fam.pam.ward.factor.5cl<-fam.pam.ward.factor.5cl
family<-data.frame(family)

# Generate separate cluster objects

cl1_5cl<-(partner.child.year.seq[family$fam.pam.ward.factor.5cl=="Early parenthood in cohabitation",1:22])
cl2_5cl<-(partner.child.year.seq[family$fam.pam.ward.factor.5cl=="LAT and long-lasting cohabitation without children",1:22])
cl3_5cl<-(partner.child.year.seq[family$fam.pam.ward.factor.5cl=="Early marriage with 1 child",1:22])
cl4_5cl<-(partner.child.year.seq[family$fam.pam.ward.factor.5cl=="Long-lasting singleness and childlessness",1:22])
cl5_5cl<-(partner.child.year.seq[family$fam.pam.ward.factor.5cl=="Early marriage with 2+ children",1:22])

# Compute the dissimimilarity matrix for each separate cluster

cl1_5cl.om<- seqdist(cl1_5cl, method="OM", indel=1, sm= "CONSTANT")
cl2_5cl.om<- seqdist(cl2_5cl, method="OM", indel=1, sm= "CONSTANT")
cl3_5cl.om<- seqdist(cl3_5cl, method="OM", indel=1, sm= "CONSTANT")
cl4_5cl.om<- seqdist(cl4_5cl, method="OM", indel=1, sm= "CONSTANT")
cl5_5cl.om<- seqdist(cl5_5cl, method="OM", indel=1, sm= "CONSTANT")

# Generate labels for x-axis

count <- seq(from = 0, to = 22, by = 2)
years <- seq(from = 18, to = 40, by = 2)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 4.5 - Relative frequency plot (only left part) ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# 50 medoid sequences for each cluster

cairo_pdf(here::here("figures", "4-2-2_Fig4-5_5clusterSolution_colors.pdf"),
          width=10,
          height=10)

def.par <- par(no.readonly = TRUE)
par(oma = c(0, 2, 2, 0))
m <- matrix(c(1,2,3,4,5,6), 3, 2, byrow = TRUE)
nf <- layout(mat = m, heights = c(0.8,0.8,0.8))
layout.show(nf)
par(mar = c(5, 3, 3, 3))

seqplot.rf.l(cl1_5cl, diss=cl1_5cl.om, 
             k=50, xlab="",cex.main=1.6, 
             title="1.Early parenthood in cohabitation (15.7%)", 
             ylab=FALSE,
             cex.lab=1.4, axes=FALSE)
mtext("Age",side = 1, line = 2.5, cex=0.9)
mtext("Medoid sequences",side = 2, line = 1.5, cex=0.9)
mtext("R2=0.27 / F-stat=1.79",side = 1, line = 4, cex=0.7)
axis(1, at = count, labels = years, font = 1, cex.axis = 1, lwd = 1)

seqplot.rf.l(cl2_5cl, diss=cl2_5cl.om, 
             k=50, xlab="",cex.main=1.6, 
             title="2.LAT/long-lasting cohabitation without children (17.5%)", 
             ylab=FALSE,
             cex.lab=1.4, axes=FALSE)
mtext("Age",side = 1, line = 2.5, cex=0.9)
mtext("Medoid sequences",side = 2, line = 1.5, cex=0.9)
mtext("R2=0.30 / F-stat=2.40",side = 1, line = 4, cex=0.7)
axis(1, at = count, labels = years, font = 1, cex.axis = 1, lwd = 1)

seqplot.rf.l(cl3_5cl, diss=cl3_5cl.om, 
             k=50, xlab="",cex.main=1.6, 
             title="3.Early marriage with 1 child (13.9%)", 
             ylab=FALSE,
             cex.lab=1.4, axes=FALSE)
mtext("Age",side = 1, line = 2.5, cex=0.9)
mtext("Medoid sequences",side = 2, line = 1.5, cex=0.9)
mtext("R2=0.45 / F-stat=3.47",side = 1, line = 4, cex=0.7)
axis(1, at = count, labels = years, font = 1, cex.axis = 1, lwd = 1)

seqplot.rf.l(cl4_5cl, diss=cl4_5cl.om, 
             k=50, xlab="",cex.main=1.6, 
             title="4.Long-lasting singleness and childlessness (14.6%)", 
             ylab=FALSE,
             cex.lab=1.4, axes=FALSE)
mtext("Age",side = 1, line = 2.5, cex=0.9)
mtext("Medoid sequences",side = 2, line = 1.5, cex=0.9)
mtext("R2=0.32 / F-stat=2.13",side = 1, line = 4, cex=0.7)
axis(1, at = count, labels = years, font = 1, cex.axis = 1, lwd = 1)

seqplot.rf.l(cl5_5cl, diss=cl5_5cl.om, 
             k=50, xlab="",cex.main=1.6, 
             title="5.Early marriage with 2+ children (38.4%)", 
             ylab=FALSE,
             cex.lab=1.4, axes=FALSE)
mtext("Age",side = 1, line = 2.5, cex=0.9)
mtext("Medoid sequences",side = 2, line = 1.5, cex=0.9)
mtext("R2=0.35 / F-stat=7.26",side = 1, line = 4, cex=0.7)
axis(1, at = count, labels = years, font = 1, cex.axis = 1, lwd = 1)

plot(1, type = "n", axes=FALSE, xlab="", ylab="")
legend(x = "center",inset = 0, legend = longlab.partner.child, col=colspace.partner.child, 
       lwd=10, cex=1.3, ncol=1)

dev.off()

pdf_convert(here::here("figures", "4-2-2_Fig4-5_5clusterSolution_colors.pdf"),
            format = "png", dpi = 300, pages = 1,
            here::here("figures", "4-2-2_Fig4-5_5clusterSolution_colors.png"))



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#save.image(here("data", "R", "yourfinlename.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

