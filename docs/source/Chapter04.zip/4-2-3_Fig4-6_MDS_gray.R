# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))

# load environment generated in "4-0_ChapterSetup.R"
load(here("data", "R", "4-0_ChapterSetup.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Preparatory work required for rendering the plot ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Multidimensional scaling of the dissimilarity matrix

mds.year.om<-cmdscale(partner.child.year.om, k = 2)

# Hierarchical clustering (Ward)

mds_ward <- hclust(as.dist(partner.child.year.om), 
                   method = "ward.D", 
                   members = family$weight40)

# Cut the clustering at 3

mds_ward_3 <-cutree(mds_ward, k = 3)

# PAM clustering

mds_pam <- wcKMedoids(partner.child.year.om, k = 3)

# Extract the 3 clusters 

mds_pam <- mds_pam$clustering 

# Re-label the clusters 1 to 3 instead of medois id 

mds_pam <- car::recode(mds_pam, "156=1; 985=2; 1735=3")

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 4.6a - MDS Ward ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~

cairo_pdf(here::here("figures", "4-2-3_Fig4-6_MDS_a_gray.pdf"),
          width=11,
          height=10)

par(mar = c(7, 7, 3, 3))

plot(mds.year.om, type = "n",
     main="Hierachical clustering (Ward's linkage)",
     ylab="Coordinate 2", 
     xlab="Coordinate 1",
     cex.lab=1.7,
     cex.main=1.7)
points(mds.year.om[mds_ward_3 == 1, ], pch = 19, col = "black")
points(mds.year.om[mds_ward_3 == 2, ], pch = 21, col = "black")
points(mds.year.om[mds_ward_3 == 3, ], pch = 24, col = "black")

legend("bottomleft", 
       pch = c(19,21,24), 
       legend = c("cluster 1", "cluster 2", "cluster 3"), 
       cex=1.6)

dev.off()

pdf_convert(here::here("figures", "4-2-3_Fig4-6_MDS_a_gray.pdf"),
            format = "png", dpi = 300, pages = 1,
            here::here("figures", "4-2-3_Fig4-6_MDS_a_gray.png"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 4.6 - b - MDS  PAM ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

cairo_pdf(here::here("figures", "4-2-3_Fig4-6_MDS_b_gray.pdf"),
          width=11,
          height=10)

par(mar = c(7, 7, 3, 3))

plot(mds.year.om, type = "n",
     main="Partitional clustering (k-medoid)",
     ylab="Coordinate 2", 
     xlab="Coordinate 1",
     cex.lab=1.7,
     cex.main=1.7)
points(mds.year.om[mds_pam == 1, ], pch = 19, col = "black")
points(mds.year.om[mds_pam == 2, ], pch = 21, col = "black")
points(mds.year.om[mds_pam == 3, ], pch = 24, col = "black")

legend("bottomleft", 
       pch = c(19,21,24), 
       legend = c("cluster 1", "cluster 2", "cluster 3"), 
       cex=1.6)

dev.off()

pdf_convert(here::here("figures", "4-2-3_Fig4-6_MDS_b_gray.pdf"),
            format = "png", dpi = 300, pages = 1,
            here::here("figures", "4-2-3_Fig4-6_MDS_b_gray.png"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 4.6 - Combined MDS Ward and PAM ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

pdf(here::here("figures", "4-2-3_Fig4-6_MDS_gray.pdf"),
    width=20,
    height=10)

par(mfrow=c(1,2))

par(mar = c(7, 7, 3, 3))

plot(mds.year.om, type = "n",
     main="Hierachical clustering (Ward's linkage)",
     ylab="Coordinate 2", 
     xlab="Coordinate 1",
     cex.lab=1.7,
     cex.main=1.7)
points(mds.year.om[mds_ward_3 == 1, ], pch = 19, col = "black")
points(mds.year.om[mds_ward_3 == 2, ], pch = 21, col = "black")
points(mds.year.om[mds_ward_3 == 3, ], pch = 24, col = "black")

legend("bottomright", pch = c(19,21,24), legend = c("cluster 1", "cluster 2", "cluster 3"), cex=1.6)
plot(silh.pam.ward.5cl, main = "(b) MDS PAM", col="grey", border=NA)


par(mar = c(7, 7, 3, 3))

plot(mds.year.om, type = "n",
     main="Partitional clustering (k-medoid)",
     ylab="Coordinate 2", 
     xlab="Coordinate 1",
     cex.lab=1.7,
     cex.main=1.7)
points(mds.year.om[mds_pam == 1, ], pch = 19, col = "black")
points(mds.year.om[mds_pam == 2, ], pch = 21, col = "black")
points(mds.year.om[mds_pam == 3, ], pch = 24, col = "black")

legend("bottomright", pch = c(19,21,24), legend = c("cluster 1", "cluster 2", "cluster 3"), cex=1.6)

dev.off()

pdf_convert(here::here("figures", "4-2-3_Fig4-6_MDS_gray.pdf"),
            format = "png", dpi = 300, pages = 1,
            here::here("figures", "4-2-3_Fig4-6_MDS_gray.png"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#save.image(here("data", "R", "yourfinlename.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
