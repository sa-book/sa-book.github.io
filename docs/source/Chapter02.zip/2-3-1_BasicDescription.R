# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))

# load environment generated in "2-0_ChapterSetup.R"
load(here("data", "R", "2-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Table 2.3 - Summary table of mean time & no of episodes ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# mean time spent in each state

statemeandur <- as_tibble(round(seqmeant(partner.month.seq, serr = TRUE)[,c(1,3)],1), 
                          rownames = "State")

statemeandur <- statemeandur %>%
  mutate(reltime = round(seqmeant(partner.month.seq, prop = TRUE),2))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# seqdss & seqmeant
# mean no of episodes by state

sum_episodes <- as_tibble(round(seqmeant(seqdss(partner.month.seq), 
                                         serr = TRUE)[,c(1,3)],1),
                          rownames = "State") %>%
  rename(ep_Mean = 2, ep_SD = 3)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# The final table summarizing
# mean time spent in each state & no of episodes
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# generate table containing both descriptives
table1 <- statemeandur %>% inner_join(sum_episodes, by = "State")

# print table
kable(table1,
      col.names = c("State", "Mean", "SD", "relative freq.", "Mean", "SD")) %>%
  add_header_above(c(" ", "Time spent in months" = 3, "Number of episodes" = 2)) %>%
  kable_styling(bootstrap_options =  c("responsive", "hover", "condensed"),
                full_width = F)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~
# 2.3.2 Transition Rates ----
# Number of transitions 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~

# monthly
m1 <- round(wtd.mean(seqtransn(partner.month.seq), family$weight40),1)
m2 <- round(sqrt(wtd.var(seqtransn(partner.month.seq), family$weight40)),1)

# yearly
y1 <- round(wtd.mean(seqtransn(partner.year.seq), family$weight40),1)
y2 <- round(sqrt(wtd.var(seqtransn(partner.year.seq), family$weight40)),1)


transfreq <- tibble(Granularity = c("Monthly data", "Yearly data"), 
                    Mean = c(m1, y1), 
                    SD = c(m2, y2))

kable(transfreq) %>%
  kable_styling(bootstrap_options = 
                  c("responsive", "hover", "condensed"),
                full_width = F)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Transition matrices (Tables 2.4 & 2.5) ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ... using monthly sequence data 

transmat.month <- seqtrate(partner.month.seq)

rownames(transmat.month) <- shortlab.partner
colnames(transmat.month) <- shortlab.partner


transmat.month.tbl <- as_tibble(round(transmat.month,2),
                                rownames = "Origin")

transmat.month.tbl %>%
  mutate(Origin = cell_spec(Origin, bold = TRUE, color = "black")) %>%
  kable(col.names = c("State at t", "S", "LAT", "COH", "MAR"),
        escape = FALSE) %>%
  add_header_above(c(" ", "State at t+1" = 4)) %>%
  kable_styling(bootstrap_options = 
                  c("responsive", "hover", "condensed"),
                full_width = F)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ... using yearly sequence data 

transmat.year <- seqtrate(partner.year.seq)

rownames(transmat.year) <- shortlab.partner
colnames(transmat.year) <- shortlab.partner

transmat.year.tbl <- as_tibble(round(transmat.year,2),
                               rownames = "Origin")

transmat.year.tbl %>%
  mutate(Origin = cell_spec(Origin, bold = TRUE, color = "black")) %>%
  kable(col.names = c("State at t", "S", "LAT", "COH", "MAR"),
        escape = FALSE) %>%
  add_header_above(c(" ", "State at t+1" = 4)) %>%
  kable_styling(bootstrap_options = 
                  c("responsive", "hover", "condensed"),
                full_width = F)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ... using monthly sequence data converted to DSS format (spell perspective)

transmat.dss <- seqtrate(seqdss(partner.month.seq))
rownames(transmat.dss) <- shortlab.partner
colnames(transmat.dss) <- shortlab.partner

transmat.dss.tbl <- as_tibble(round(transmat.dss,2),
                              rownames = "Origin")

transmat.dss.tbl %>%
  mutate(Origin = cell_spec(Origin, bold = TRUE, color = "black")) %>%
  kable(col.names = c("State at t", "S", "LAT", "COH", "MAR"),
        escape = FALSE) %>%
  add_header_above(c(" ", "State at t+1" = 4)) %>%
  kable_styling(bootstrap_options = 
                  c("responsive", "hover", "condensed"),
                full_width = F)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# State distributions and Shannon entropy (Tables 2.6 & 2.7) ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Table 2.6
statedis <- seqstatd(partner.month.seq)$Frequencies

statedis2 <- as_tibble(round(statedis[,c(1, seq(24, 264, by = 48))],2),
                       rownames = "State")

kable(statedis2,
      col.names = c("State", 18, seq(20,40, by = 4))) %>%
  add_header_above(c(" ", "State distribution at age" = 7)) %>%
  kable_styling(bootstrap_options = 
                  c("responsive", "hover", "condensed"),
                full_width = F)


# Table 2.7
stateentropy <- seqstatd(partner.month.seq)$Entropy
stateentropy2 <- round(stateentropy[c(1, seq(24, 264, by = 48))],2)

stateentropy2 %>%
  t(.) %>%
  kable(.,col.names = c(18, seq(20,40, by = 4))) %>%
  add_header_above(c("Shannon entropy at age ..." = 7)) %>%
  kable_styling(bootstrap_options = 
                  c("responsive", "hover", "condensed"),
                full_width = F)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Additional information reported in the last paragraph of 2.3.3 ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# lowest share of singles across entire sequence
minimum.single <- as_tibble(seqstatd(partner.month.seq)$Frequencies) %>%
  t() %>% 
  as_tibble() %>% 
  summarise(Min = min(V1)) %>%
  pull()

glue("The share of singles never falls below {round(minimum.single,2)*100}%")

# Share of persons who were permanently single (weighted)
as_tibble(seqistatd(partner.month.seq)) %>%
  mutate(steadysingle = S == 264) %>% 
  summarise(steadysingle = round(weighted.mean(steadysingle, 
                                               w = family$weight40)*100,2)) %>% 
  pull() %>% 
  glue("% are permanently single")
  

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Extract modal sequences ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

modal.month.seq <- seqdef(as_tibble(seqmodst(partner.month.seq)))
mm <- print(modal.month.seq, format = "SPS")

modal.year.seq <- seqdef(as_tibble(seqmodst(partner.year.seq)))
my <- print(modal.year.seq, format = "SPS")

modalseqs <- tibble(Granularity = c("Monthly data", "Yearly data"), 
                    'Modal Sequence' = c(mm, my))

kable(modalseqs) %>%
  kable_styling(bootstrap_options = 
                  c("responsive", "hover", "condensed"),
                full_width = F)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Table 2.8 -  Representative sequences ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# .... using yearly data

partner.year.rep <- seqrep(partner.year.seq, 
                           diss=partner.year.om, 
                           criterion="density")

regular.rows <- nrow(partner.year.rep)

var1 <- c(print(partner.year.seq[attributes(partner.year.rep)$Index,], 
                format = "SPS"), "Total Coverage")
var2 <- attributes(partner.year.rep)$Statistics[,4]
var3 <- attributes(partner.year.rep)$Statistics[,2]



partner.year.rep <- tibble(Sequence = var1, 
                           Coverage = round(var2,1),
                           Assigned = round(var3,1)) %>%
  mutate(Coverage = case_when(Coverage == max(Coverage) ~ (Coverage*-1),
                              TRUE ~ Coverage)) %>%
  arrange(desc(Coverage)) %>%
  mutate(Coverage = case_when(Coverage == min(Coverage) ~ (Coverage*-1),
                              TRUE ~ Coverage)) 

kable(partner.year.rep, format = "html", escape = F,
      col.names = c("Sequence", "Coverage<br>(in %)", "Assigned<br>(in %)")) %>%
  column_spec(1, bold = c(rep(FALSE,regular.rows), TRUE)) %>% 
  kable_styling(bootstrap_options = 
                  c("responsive", "hover", "condensed"),
                full_width = F)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Additional information reported in the last paragraph of 2.3.4 ----
# Medoid sequences and their coverage by gender
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# extracting medoid sequences by sex using yearly data
partner.year.sex.rep <- seqrep.grp(partner.year.seq,
                                   group = family$sex,
                                   diss=partner.year.om,
                                   criterion="dist",
                                   nrep=1,
                                   ret = "both")

# Medoid & coverage - men (family$sex = 0 = male)
print(partner.year.sex.rep[[1]]$` 0`, format = "SPS")
attributes(partner.year.sex.rep[[1]]$` 0`)$Statistics[1,4]

# Medoid & coverage - women (family$sex = 1 = female)
print(partner.year.sex.rep[[1]]$` 1`, format = "SPS")
attributes(partner.year.sex.rep[[1]]$` 1`)$Statistics[1,4]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
