# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))


# load environment generated in "2-0_ChapterSetup.R"
load(here("data", "R", "2-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# 2.5.1 Unidimensional Measures 
# Sequencing — counting transitions and subsequences (including Table 2.9) ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Example sequences 
seqX <- c("S","LAT","COH","MAR")
seqY <- c("S","LAT","COH","S")

ex1.seq <- seqdef(rbind(seqX,seqY), alphabet = seqX)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Number of transitions
seqtransn(ex1.seq)

# Normalized version
seqtransn(ex1.seq, norm = TRUE) 


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Number of subsequences
seqsubsn(ex1.seq)

# Normalized version
seqsubsn.max <- rep(alphabet(ex1.seq), length.out = max(seqlength(ex1.seq)))
seqsubsn.max <- seqsubsn(seqdef(t(seqsubsn.max)))
round((log2(seqsubsn(ex1.seq))-1)/
      (log2(rep(seqsubsn.max,nrow(ex1.seq)))-1),2)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Table 2.9

# Extract & display all possible subsequences of Sequence x
subseqsX <- vector(mode = "list", length = length(seqX))

for (i in rev(seq_along(seqX))) {
  subseqsX[[i]] <- as.data.frame(t(combn(seqX, i)))
}

subseqsX <- bind_rows(subseqsX)
subseqsX <- add_row(subseqsX, .before = 1)
subseqsX <- distinct(subseqsX)
subseqsX <- print(seqdef(subseqsX), format = "SPS")
subseqsX[1,1] <- "$\\lambda$"
colnames(subseqsX) <- "Sequence x"


# Extract & display all possible subsequences of Sequence y
subseqsY <- vector(mode = "list", length = length(seqY))

for (i in rev(seq_along(seqY))) {
  subseqsY[[i]] <- as.data.frame(t(combn(seqY, i)))
}

subseqsY <- bind_rows(subseqsY)
subseqsY <- add_row(subseqsY, .before = 1)
subseqsY <- distinct(subseqsY)
subseqsY <- print(seqdef(subseqsY), format = "SPS")
subseqsY[1,1] <- "$\\lambda$"
colnames(subseqsY) <- "Sequence y"

# Table: Subsequences of Sequences x & y
kable(list(subseqsX,subseqsY)) %>%
  kable_styling(bootstrap_options = 
                  c("responsive", "hover", "condensed"),
                full_width = F)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# 2.5.1 Unidimensional Measures 
# Duration – longitudinal Shannon entropy ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Example sequences 
seqX2 <- rep(c("S","LAT","COH","MAR"),2)
seqY2 <- rep(c("S","LAT","COH","MAR"),c(2,2,2,2))

ex2.seq <- seqdef(rbind(seqX2,seqY2),
                  alphabet = c("S","LAT","COH","MAR"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Number of transitions
seqtransn(ex2.seq)

# Normalized version
seqtransn(ex2.seq, norm = TRUE)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Number of subsequences
seqsubsn(ex2.seq)

# Normalized version
seqsubsn.max <- rep(alphabet(ex2.seq), length.out = max(seqlength(ex2.seq)))
seqsubsn.max <- seqsubsn(seqdef(t(seqsubsn.max)))
round((log2(seqsubsn(ex2.seq))-1)/
        (log2(rep(seqsubsn.max,nrow(ex2.seq)))-1),2)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Shannon Entropy
seqient(ex2.seq)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Table 2-10: Comparison of different indices ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Construct set of example sequences
data <- matrix(c(rep("S", 20),
                 rep("MAR", 20),
                 c(rep("MAR", 5)), rep("COH", 5), rep("LAT", 5), rep("S", 5),
                 c(rep("S", 5), rep("LAT", 5), rep("COH", 5), rep("MAR", 5)),
                 c(rep("S", 3), rep("LAT", 1), rep("COH", 6), rep("MAR", 10)),
                 c(rep("S", 4), rep("LAT", 4), rep("COH", 6), rep("MAR", 6)),
                 c(rep("MAR", 6), rep("S", 4), rep("LAT", 4), rep("COH", 6)),
                 c(rep("S", 10), rep("MAR", 10)),
                 c(rep("S", 2), rep("LAT", 5), rep("S", 3), rep("COH", 5), rep("MAR", 5)),
                 c(rep("S", 2), rep("LAT", 5), rep("COH", 5), rep("MAR", 5), rep("S", 3)),
                 c(rep("S", 2), rep("MAR", 10), rep("COH", 8)),
                 c(rep("S", 2), rep("MAR", 2), rep("COH", 8), rep("MAR", 8))), 
               nrow = 12, byrow = TRUE)


example.seq <- seqdef(data, alphabet = c("S","LAT","COH","MAR"))
example.sps <- print(example.seq, format = "SPS")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Number of transitions
transitions <- seqtransn(example.seq)
transitions.norm <- round(seqtransn(example.seq, norm = TRUE),2)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Within sequence entropies
entropy <- seqient(example.seq)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Turbulence
turbulence <- seqST(example.seq, norm = TRUE)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Complexity
complexity <- seqici(example.seq)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Precarity index
precarity <- seqprecarity(example.seq,
                          state.order = rev(alphabet(example.seq)))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Sequence quality index
# considering only Marriage as a success
quality <- seqindic(example.seq, indic=c("integr"),
                    ipos.args=list(pos.states=c("MAR")),
                    w = 1)

colnames(quality) <- "Quality"

# Note: The seqquality-function (https://github.com/maraab23/seqquality)
# allows for a more comprehensive implementation of the quality index
# (including a time-varying computation)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Print all indices in a joint table (Table 2.10)
tab2.10 <- data.frame(example.sps,
                      Transitions = as.vector(transitions.norm),
                      entropy,
                      turbulence,
                      Complexity = as.vector(complexity),
                      Precarity = as.vector(precarity),
                      quality)

kable(tab2.10, digits = 2) %>%
  kable_styling(bootstrap_options = 
                  c("responsive", "hover", "condensed"),
                full_width = F)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Correlation between Complexity and Turbulence (subsection: Complexity) ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# for the manually generated example data
cor(complexity,turbulence)

# for the pairfam data
complexity2 <- seqici(partner.year.seq)
turbulence2 <- seqST(partner.year.seq, norm = TRUE)
cor(complexity2,turbulence2)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Table 2.11. - Regression using Complexity and Turbulence ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

regdata <- family %>%
  select(sex, east, famstructure18, highschool, migstatus) %>%
  mutate(complexity = as.numeric(seqici(partner.child.year.seq)),
         turbulence = as.numeric(seqST(partner.child.year.seq, norm = TRUE))) %>%
  filter(migstatus != -7) %>%
  mutate(migstatus = as_factor(migstatus)) 
  
lm.turbulence <- lm(turbulence ~ sex + highschool + migstatus, data = regdata)
lm.complexity <- lm(complexity ~ sex + highschool + migstatus, data = regdata)

# Generate regression table using sjPlot-package
tab_model(lm.turbulence,lm.complexity, 
          show.ci = FALSE,
          pred.labels = c("Intercept", "Gender: female",
                          "Education: at least high school",
                          "Migration background: 1st generation", 
                          "2nd generation"), 
          p.style="stars") 

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
