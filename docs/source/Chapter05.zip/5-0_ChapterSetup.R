# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~
# Import data ----
# ~~~~~~~~~~~~~~~~

# Import Stata data sets using haven 

family <- read_dta(here("data", "Stata", "PartnerBirthbio.dta"))

activity <- read_dta(here("data", "Stata", "Activitybio.dta"))

multidim <- read_dta(here("data", "Stata", "MultiChannel.dta"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Extracting and recoding sequence variables ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# family biographies

seqvars.partner.child <- family %>%
  dplyr::select(starts_with("state"))

# ------------------------------------------------------------------------------

# activity biographies
seqvars.activity <- activity %>%
  dplyr::select(starts_with("state"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Define labels for different alphabets ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ------------------------------------------------------------------------------

# full state space - partner & birth bio

shortlab.partner.child <- c("S", "Sc", 
                            "LAT", "LATc", 
                            "COH", "COHc",
                            "MAR", "MARc1", "MARc2+")

longlab.partner.child <- names(attributes(seqvars.partner.child$state1)$labels)


# ------------------------------------------------------------------------------

# full state space - partner & birth bio

shortlab.activity <- c("EDU", "MIL/CS",
                       "PT", "FT", "SELF",
                       "PLEAVE", "MARGINAL", "UNEMP")

longlab.activity <- names(attributes(seqvars.activity$state1)$labels)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Define different color palettes ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Note:
# The choice of colors is addressed at length in a separate script
# and also covered on a dedicated page of the companion website


# ------------------------------------------------------------------------------

# Family colors
col1 <- sequential_hcl(5, palette = "Blues")[3:2]   # Single states
col2 <- sequential_hcl(5, palette = "Greens")[2:1]  # LAT states
col3 <- sequential_hcl(5, palette = "Oranges")[3:2] # Cohabitation states
col4 <- sequential_hcl(5, palette = "magenta")[3:1] # Married states

# Combine to full color palette
colspace.partner.child <- c(col1, col2, col3, col4)

# ------------------------------------------------------------------------------

# Activity colors
col1 <- sequential_hcl(5, palette = "Burg", rev = TRUE)[c(2,4)]
col2 <- sequential_hcl(8, palette = "ag_GrnYl", rev = T)[c(4,6,8,2)]
col3 <- sequential_hcl(5, palette = "Heat")[3:2]

# Combine to full color palette
colspace.activity <- c(col1, col2, col3)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~
# Defining sequences ----
# ~~~~~~~~~~~~~~~~~~~~~~~


match("family1",names(multidim))
match("family264",names(multidim))

match("activity1",names(multidim))
match("activity264",names(multidim))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Labor market: full state space no weights

mc.act.month.seq.now <- seqdef(multidim, 282:545,
                               states = shortlab.activity,
                               labels = longlab.activity, alphabet = c(1:8),  
                               cpal = colspace.activity,
                               xtstep = 12)

mc.act.year.seq.now <- seqgranularity(mc.act.month.seq.now,
                                      tspan=12, method="mostfreq")

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Family formation: full state space no weights

mc.fam.month.seq.now <- seqdef(multidim, 18:281,
                               states = shortlab.partner.child,
                               labels = longlab.partner.child, alphabet = c(1:9),  
                               cpal = colspace.partner.child,
                               xtstep = 12)

mc.fam.year.seq.now <- seqgranularity(mc.fam.month.seq.now,
                                      tspan=12, method="mostfreq")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Labor market: full state space weights

mc.act.month.seq <- seqdef(multidim, 282:545,
                           states = shortlab.activity,
                           labels = longlab.activity, alphabet = c(1:8),  
                           weights = multidim$weight40,
                           cpal = colspace.activity,
                           xtstep = 12)

mc.act.year.seq <- seqgranularity(mc.act.month.seq,
                                  tspan=12, method="mostfreq")

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Family formation: full state space no weights

mc.fam.month.seq <- seqdef(multidim, 18:281,
                           states = shortlab.partner.child,
                           labels = longlab.partner.child, alphabet = c(1:9),  
                           weights = multidim$weight40,
                           cpal = colspace.partner.child,
                           xtstep = 12)

mc.fam.year.seq <- seqgranularity(mc.fam.month.seq,
                                  tspan=12, method="mostfreq")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Compute standard OM distance matrices for yearly data ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


mc.act.year.om.now <- seqdist(mc.act.year.seq.now, method="OM", indel=1, sm= "CONSTANT")
mc.fam.year.om.now <- seqdist(mc.fam.year.seq.now, method="OM", indel=1, sm= "CONSTANT")

mc.act.year.om <- seqdist(mc.act.year.seq, method="OM", indel=1, sm= "CONSTANT")
mc.fam.year.om <- seqdist(mc.fam.year.seq, method="OM", indel=1, sm= "CONSTANT")

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

save.image(here("data", "R", "5-0_ChapterSetup.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
