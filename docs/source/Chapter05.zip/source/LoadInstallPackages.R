
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Load and download (if necessary) required packages ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

## Save package names as a vector of strings
pkgs <- c("TraMineR", "TraMineRextras", "tidyverse", "haven", "Cairo", "reshape2", 
          "glue", "RColorBrewer", "colorspace", "Hmisc", "knitr", "kableExtra", 
          "pdftools", "cluster", "patchwork", "OpenMx", "grDevices", "corrplot", 
          "car", "factoextra", "WeightedCluster", "nnet", "descr", "stats", 
          "psych", "effects", "ggseqplot", "ggh4x")

# Options that might help to prevent some errors in the installation process
options(install.packages.check.source = "no")
options(install.packages.compile.from.source = "never")


## Install uninstalled packages
lapply(pkgs[!(pkgs %in% installed.packages())], 
       install.packages, repos = getOption("repos")["CRAN"])


## Load all packages to library and adjust options
lapply(pkgs, library, character.only = TRUE)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
