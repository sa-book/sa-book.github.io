# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# load environment generated in "5-0_ChapterSetup.R"
load(here("data", "R", "5-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~
# Summation ----
# ~~~~~~~~~~~~~~

X <- list(mc.fam.year.om, mc.act.year.om)

Y <- do.call(cbind, X)

Y <- array(Y, dim=c(dim(X[[1]]), length(X)))

mc.summation<-apply(Y, c(1, 2), sum, na.rm = TRUE)

# ~~~~~~~~~~~~~~
# Averaging ----
# ~~~~~~~~~~~~~~

X <- list(mc.act.year.om, mc.fam.year.om)

Y <- do.call(cbind, X)

Y <- array(Y, dim=c(dim(X[[1]]), length(X)))

mc.average<-apply(Y, c(1, 2), mean, na.rm = TRUE)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Table 5.2 - Separate and joint dissimilarity matrices ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Separate dissimilarity matrix for 3 selected sequences in the data

fam.sel<-mc.fam.year.om[1:3, 1:3]

print(fam.sel)

act.sel<-mc.act.year.om[1:3, 1:3]

print(act.sel)

# Ex-post joint dissimilarity matrices

#-- Summation

sum.sel<-mc.summation[1:3, 1:3]

print(sum.sel)


#-- Averaging 

ave.sel<-mc.average[1:3, 1:3]

print(ave.sel)

# Export the tables as separate.csv

write.csv(fam.sel, (here("tables", "Chapter5-4_Tab5-2a.csv")))
write.csv(act.sel, (here("tables", "Chapter5-4_Tab5-2b.csv")))
write.csv(sum.sel, (here("tables", "Chapter5-4_Tab5-2c.csv")))
write.csv(ave.sel, (here("tables", "Chapter5-4_Tab5-2d.csv")))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#save.image(here("data", "R", "yourfinlename.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


