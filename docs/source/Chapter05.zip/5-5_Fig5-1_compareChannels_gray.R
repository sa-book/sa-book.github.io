# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# load environment generated in "5-0_ChapterSetup.R"
load(here("data", "R", "5-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Preparatory work required for rendering the plot ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Defining the label for the x-axis 

xtlab<-seq(18,40, by = 1)


# Defining the range of the x axis 

x <- 2:15

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Extract r2 and silhouette for the combined clustering

mcdist.om <- seqdistmc(channels=list(mc.fam.year.seq, mc.act.year.seq),
                       method="OM", indel=1, sm="CONSTANT", 
                       cweight=c(1,1))

mcdist.om.pam <- wcKMedRange(mcdist.om, 
                             weights = multidim$weight40, 
                             kvals = 2:15)

mc.val<-mcdist.om.pam[[4]]

mc.asw <- mc.val[,4]

mc.r2 <- mc.val[,7]

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Extract r2 and silhouette for the clustering of family trajectories

fam.pam.test <- wcKMedRange(mc.fam.year.om, 
                            weights = multidim$weight40, 
                            kvals = 2:15)

fam.val<-fam.pam.test[[4]]

fam.asw <- fam.val[,4]

fam.r2 <- fam.val[,7]

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Extract r2 and silhouette for the clustering of labour market trajectories

act.pam.test <- wcKMedRange(mc.act.year.om, 
                            weights = multidim$weight40, 
                            kvals = 2:15)

act.val<-act.pam.test[[4]]

act.asw <- act.val[,4]

act.r2 <- act.val[,7]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 5.1 - Compare separate channels and MCSA ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



cairo_pdf(here::here("figures", "5-5_Fig5-1_heuristic_gray.pdf"),
          width=15,
          height=5)

layout.fig1 <- layout(matrix(c(1,2,3), 1, 3, byrow = TRUE),
                      heights = c(1,1,1))
layout.show(layout.fig1)

par(mar = c(5, 5, 3, 3))


plot(x, fam.asw, type = "b", frame = FALSE, pch = 19, main="(a) Family formation",
     col = "black", xlab = "N. clusters", ylab = "ASW and R2 value", ylim = c(0,0.6),
     cex.main=2,
     cex.lab=1.6,
     cex.axis=1.2)
# Add a second line
lines(x, fam.r2, pch = 19, col = "black", type = "b", lty = 2)
# Add a legend to the plot
legend("bottomright", legend=c("ASW", "R2"),
       col=c("black", "black"), lty = 1:2, cex=1.2)

plot(x, act.asw, type = "b", frame = FALSE, pch = 19, main="(b) Labor market", 
     col = "black", xlab = "N. clusters", ylab = "", ylim = c(0,0.6),
     cex.main=2,
     cex.lab=1.6,
     cex.axis=1.2)
# Add a second line
lines(x, act.r2, pch = 19, col = "black", type = "b", lty = 2)
# Add a legend to the plot
legend("bottomright", legend=c("ASW", "R2"),
       col=c("black", "black"), lty = 1:2, cex=1.2)

plot(x, mc.asw, type = "b", frame = FALSE, pch = 19, main="(c) MCSA", 
     col = "black", xlab = "N. clusters", ylab = "", ylim = c(0,0.6),
     cex.main=2,
     cex.lab=1.6,
     cex.axis=1.2)
# Add a second line
lines(x, mc.r2, pch = 19, col = "black", type = "b", lty = 2)
# Add a legend to the plot
legend("bottomright", legend=c("ASW", "R2"),
       col=c("black", "black"), lty = 1:2, cex=1.2)

dev.off()


pdf_convert(here::here("figures", "5-5_Fig5-1_heuristic_gray.pdf"),
            format = "png", dpi = 300, pages = 1,
            here::here("figures", "5-5_Fig5-1_heuristic_gray.png"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#save.image(here("data", "R", "yourfinlename.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


