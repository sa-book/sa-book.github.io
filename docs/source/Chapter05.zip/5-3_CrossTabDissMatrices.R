# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# load environment generated in "5-0_ChapterSetup.R"
load(here("data", "R", "5-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Preparatory work required for the table ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Family formation: extract 5 clusters

#-- Ward clustering

fam.ward<-hclust(as.dist(mc.fam.year.om), 
                       method="ward.D", 
                       members=multidim$weight40)

#-- PAM clustering + Ward

fam.pam <- wcKMedRange(mc.fam.year.om, 
                            weights = multidim$weight40, 
                            kvals = 2:10,
                            initialclust = fam.ward)

#-- Extract 5 clusters

fam.pam.5cl <- fam.pam$clustering$cluster5

#-- Attach the cluster info to the main data.frame "multidim"

multidim$fam.pam.5cl<-fam.pam.5cl

#-- Re-label clusters from 1 to 5 instead of medoid id

fam.pam.5cl.factor <- factor(fam.pam.5cl, 
                             levels = c(16, 460, 479, 892, 898), 
                             c("1", "2", "3", "4", "5"))

#-- Attach the factor info to the main data.frame "multidim"

multidim$fam.pam.5cl.factor<-fam.pam.5cl.factor

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Labour market: extract 5 clusters

#-- Ward clustering

act.ward<-hclust(as.dist(mc.act.year.om), 
                 method="ward.D", 
                 members=multidim$weight40)

#-- PAM clustering + Ward

act.pam <- wcKMedRange(mc.act.year.om, 
                       weights = multidim$weight40, 
                       kvals = 2:10,
                       initialclust = act.ward)

#-- Extract 5 clusters

act.pam.5cl <- act.pam$clustering$cluster5

#-- Attach the cluster info to the main data.frame "multidim"

multidim$act.pam.5cl<-act.pam.5cl

#-- Re-label clusters from 1 to 5 instead of medoid id

act.pam.5cl.factor <- factor(act.pam.5cl, 
                             levels = c(6, 25, 78, 539, 709), 
                             c("1", "2", "3", "4", "5"))

#-- Attach the factor info to the main data.frame "multidim"

multidim$act.pam.5cl.factor<-act.pam.5cl.factor

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Table 5.1 - Cross-tabulation for a 5-cluster solution on both channels  ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

crosstab<-table(multidim$act.pam.5cl.factor, multidim$fam.pam.5cl.factor)


# Export the table as .csv

write.csv(crosstab, (here("tables", "Chapter5-3_Tab5-1.csv")))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#save.image(here("data", "R", "yourfinlename.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


