# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))


# load environment generated in "5-0_ChapterSetup.R"
load(here("data", "R", "5-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Preparatory work required for rendering the plot ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Calculate the joint dissimilarity matrix

mcdist.om <- seqdistmc(channels=list(mc.fam.year.seq, mc.act.year.seq),
                       method="OM", indel=1, sm="CONSTANT", 
                       cweight=c(1,1))

# Apply PAM clustering + Ward starting point

mcdist.om.ward<-hclust(as.dist(mcdist.om), method="ward.D", members=multidim$weight40)

mcdist.om.pam.ward <- wcKMedRange(mcdist.om, weights = multidim$weight40, kvals = 2:10,
                                  initialclust = mcdist.om.ward)

# Cut tree at cluster==5

mc <- mcdist.om.pam.ward$clustering$cluster5

# Label the clusters from 1 to 5

mc.factor <- factor(mc, levels = c(16, 202, 439, 795, 892), 
                    c("1", "2", "3", "4", "5"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Separate objects for each channel and for each cluster (=5*2)

multidim$mc.factor <- as.numeric(mc.factor)

# Identify position of variables indicating start and end of sequences

fam1.seq <- mc.fam.year.seq[multidim$mc.factor == "1", ]
fam2.seq <- mc.fam.year.seq[multidim$mc.factor == "2", ]
fam3.seq <- mc.fam.year.seq[multidim$mc.factor == "3", ]
fam4.seq <- mc.fam.year.seq[multidim$mc.factor == "4", ]
fam5.seq <- mc.fam.year.seq[multidim$mc.factor == "5", ]

act1.seq <- mc.act.year.seq[multidim$mc.factor == "1", ]
act2.seq <- mc.act.year.seq[multidim$mc.factor == "2", ]
act3.seq <- mc.act.year.seq[multidim$mc.factor == "3", ]
act4.seq <- mc.act.year.seq[multidim$mc.factor == "4", ]
act5.seq <- mc.act.year.seq[multidim$mc.factor == "5", ]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Obtain relative frequencies of the five cluster (using weights)

relfreq <- multidim %>% 
  count(mc.factor, wt = weight40) %>% 
  mutate(share = n/ sum(n)) %>%
  arrange(share)

# Convert relative frequencies to percentages (will be used for labeling the y-axes)

share <- round(as.numeric(relfreq$share)*100, 1)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 5.5 - MCSA plots ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Sequences ordered by multidimensional scaling on both channels 

cairo_pdf(here::here("figures", "5-5_Fig5-2_MCSA_colors_joint.pdf"),
          width=12,
          height=12)

def.par <- par(no.readonly = TRUE)

# Each state disribution plot will be displayed according to its relative size
# as we add some additional rows to the cluster some adjustments are required
heights.mc <- c(.05,as.numeric(relfreq$share)*.97,.03)
widths.mc <- c(0.1, 0.325, 0.325, 0.25)

# Specifying the location of the many figures/elements we want to plot
layout.mc <- layout(matrix(c(1,2,3,21,
                             4,5,6,21,
                             7,8,9,22,
                             10,11,12,22,
                             13,14,15,23,
                             16,17,18,23,
                             19,20,20,23), 7, 4, byrow = TRUE), 
                    widths = widths.mc, 
                    heights = heights.mc)
layout.show(layout.mc)

# Labelling of the x-axes
count <- seq(from = 0, to = 22, by = 2)
years <- seq(from = 18, to = 40, by = 2)

# start with the actual graph...

# Row 1 - columns 1-3
par(mar = c(0.2,0,0.2,0))
plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')

plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
text(x = 0.5, y = 0.5, paste0("Family formation"), 
     cex = 2.5, col = "black", font = 2)

plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
text(x = 0.5, y = 0.5, paste0("Labor market"), 
     cex = 2.5, col = "black", font = 2)

# Row 2 - columns 1-3
par(mar = c(2,1,0,0))
plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
text(x = 0.5, y = 0.5, paste0("Cluster 1\n","(",share[1], "%)"), 
     cex = 1.4, col = "black", font = 2)

par(mar = c(2,1,0,1))
seqIplot(mc.fam.year.seq[multidim$mc.factor == relfreq$mc.factor[1],],
         sortv = cmdscale(mcdist.om[multidim$mc.factor == relfreq$mc.factor[1],
                                    multidim$mc.factor == relfreq$mc.factor[1]], k = 2),
         with.legend = FALSE, border = NA, 
         axes = FALSE, yaxis = FALSE,  ylab = "")

seqIplot(mc.act.year.seq[multidim$mc.factor == relfreq$mc.factor[1],]
         , sortv = cmdscale(mcdist.om[multidim$mc.factor == relfreq$mc.factor[1],
                                              multidim$mc.factor == relfreq$mc.factor[1]], k = 2)
         , with.legend = FALSE, border = NA, 
         axes = FALSE, yaxis = FALSE,  ylab = "")

# Row 3 - columns 1-3
par(mar = c(2,1,0,0))
plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
text(x = 0.5, y = 0.5, paste0("Cluster 2\n","(",share[2], "%)"), 
     cex = 1.4, col = "black", font = 2)

par(mar = c(2,1,0,1))
seqIplot(mc.fam.year.seq[multidim$mc.factor == relfreq$mc.factor[2],],
         sortv = cmdscale(mcdist.om[multidim$mc.factor == relfreq$mc.factor[2],
                                    multidim$mc.factor == relfreq$mc.factor[2]], k = 2),
         with.legend = FALSE, border = NA, 
         axes = FALSE, yaxis = FALSE,  ylab = "")

seqIplot(mc.act.year.seq[multidim$mc.factor == relfreq$mc.factor[2],]
         , sortv = cmdscale(mcdist.om[multidim$mc.factor == relfreq$mc.factor[2],
                                              multidim$mc.factor == relfreq$mc.factor[2]], k = 2)
         , with.legend = FALSE, border = NA, 
         axes = FALSE, yaxis = FALSE,  ylab = "")

# Row 4 - columns 1-3
par(mar = c(2,1,0,0))
plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
text(x = 0.5, y = 0.5, paste0("Cluster 3\n","(",share[3], "%)"), 
     cex = 1.4, col = "black", font = 2)

par(mar = c(2,1,0,1))
seqIplot(mc.fam.year.seq[multidim$mc.factor == relfreq$mc.factor[3],], 
         sortv = cmdscale(mcdist.om[multidim$mc.factor == relfreq$mc.factor[3],
                                    multidim$mc.factor == relfreq$mc.factor[3]], k = 2)
         , with.legend = FALSE, border = NA, 
         axes = FALSE, yaxis = FALSE,  ylab = "")

seqIplot(mc.act.year.seq[multidim$mc.factor == relfreq$mc.factor[3],]
         , sortv = cmdscale(mcdist.om[multidim$mc.factor == relfreq$mc.factor[3],
                                              multidim$mc.factor == relfreq$mc.factor[3]], k = 2)
         , with.legend = FALSE, border = NA, 
         axes = FALSE, yaxis = FALSE,  ylab = "")

# Row 5 - columns 1-3
par(mar = c(2,1,0,0))
plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
text(x = 0.5, y = 0.5, paste0("Cluster 4\n","(",share[4], "%)"), 
     cex = 1.4, col = "black", font = 2)

par(mar = c(2,1,0,1))
seqIplot(mc.fam.year.seq[multidim$mc.factor == relfreq$mc.factor[4],],
         sortv = cmdscale(mcdist.om[multidim$mc.factor == relfreq$mc.factor[4],
                                    multidim$mc.factor == relfreq$mc.factor[4]], k = 2)
                          , with.legend = FALSE, border = NA, 
         axes = FALSE, yaxis = FALSE,  ylab = "")

seqIplot(mc.act.year.seq[multidim$mc.factor == relfreq$mc.factor[4],]
         , sortv = cmdscale(mcdist.om[multidim$mc.factor == relfreq$mc.factor[4],
                                              multidim$mc.factor == relfreq$mc.factor[4]], k = 2)
                                    , with.legend = FALSE, border = NA, 
         axes = FALSE, yaxis = FALSE,  ylab = "")

# Row 6 - columns 1-3
par(mar = c(2,1,0,0))
plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
text(x = 0.5, y = 0.5, paste0("Cluster 5\n","(",share[5], "%)"), 
     cex = 1.4, col = "black", font = 2)

par(mar = c(2,1,0,1))
seqIplot(mc.fam.year.seq[multidim$mc.factor == relfreq$mc.factor[5],], 
         sortv = cmdscale(mcdist.om[multidim$mc.factor == relfreq$mc.factor[5],
                                    multidim$mc.factor == relfreq$mc.factor[5]], k = 2)
         , with.legend = FALSE, border = NA, 
         axes = FALSE, yaxis = FALSE,  ylab = "")
axis(1, at=(seq(0,22, by = 2)), labels = seq(18,40, by = 2), font = 1, cex.axis = 1.2, lwd = 1)

seqIplot(mc.act.year.seq[multidim$mc.factor == relfreq$mc.factor[5],]
         , sortv = cmdscale(mcdist.om[multidim$mc.factor == relfreq$mc.factor[5],
                                              multidim$mc.factor == relfreq$mc.factor[5]], k = 2)
                                    , with.legend = FALSE, border = NA, 
         axes = FALSE, yaxis = FALSE,  ylab = "")
axis(1, at = count, labels = years, font = 1, cex.axis = 1.2, lwd = 1)

# Row 7 - columns 1-3
par(mar = c(0.2,0,0.2,0))
plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')

plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
text(x = 0.5, y = 0.5, paste0("Age"), 
     cex = 1.5, col = "black", font = 2)

# Column 4 
par(mar = c(0.2,0,0.2,0))
plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')

par(mar = c(4,1,4,1))
plot(1, type = "n", axes = FALSE, xlab = "", ylab = "")
legend(x = "top",inset = 0, legend = longlab.partner.child, col = colspace.partner.child, 
       lwd = 10, cex = 1.5, ncol = 1, box.lwd = 2)
mtext("Family formation",side = 3, line = 1, cex = 1.2, font = 2)

plot(1, type = "n", axes = FALSE, xlab = "", ylab = "")
legend(x = "top",inset = 0, legend = longlab.activity, col = colspace.activity, 
       lwd = 10, cex = 1.5, ncol = 1, box.lwd = 2)
mtext("Labor market",side = 3, line = 1, cex = 1.2, font = 2)

par(def.par)
dev.off()


pdf_convert(here::here("figures", "5-5_Fig5-2_MCSA_colors_joint.pdf"),
            format = "png", dpi = 400, pages = 1,
            here::here("figures", "5-5_Fig5-2_MCSA_colors_joint.png"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#save.image(here("data", "R", "yourfinlename.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~