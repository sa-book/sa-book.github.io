# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))

# load environment generated in "3-0_ChapterSetup.R"
load(here("data", "R", "3-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Preparatory work required for rendering the plot ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Calculate necessary substitution costs matrices

#--- om.s2.i1

costs.sm2 <- matrix(
  c(0,2,2,2,2,2,2,2,2,
    2,0,2,2,2,2,2,2,2,
    2,2,0,2,2,2,2,2,2,
    2,2,2,0,2,2,2,2,2,
    2,2,2,2,0,2,2,2,2,
    2,2,2,2,2,0,2,2,2,
    2,2,2,2,2,2,0,2,2,
    2,2,2,2,2,2,2,0,2,
    2,2,2,2,2,2,2,2,0
  ),
  nrow = 9, ncol = 9, byrow = TRUE)

#--- om.s1.i4

costs.sm1 <- matrix(
  c(0,1,1,1,1,1,1,1,1,
    1,0,1,1,1,1,1,1,1,
    1,1,0,1,1,1,1,1,1,
    1,1,1,0,1,1,1,1,1,
    1,1,1,1,0,1,1,1,1,
    1,1,1,1,1,0,1,1,1,
    1,1,1,1,1,1,0,1,1,
    1,1,1,1,1,1,1,0,1,
    1,1,1,1,1,1,1,1,0
  ),
  nrow = 9, ncol = 9, byrow = TRUE)

#--- state properties

partner <- c(0, 0, 1, 1, 1, 1, 1,1,1)
child <- c(0,1,0,1,0,1,0,1,2)
alphabetprop <- data.frame(partner = partner, child = child)
rownames(alphabetprop) <- alphabet(partner.child.year.seq)
prop <- seqcost(partner.child.year.seq, method="FEATURES",
                    state.features = alphabetprop)

#--- theory-based

theo <- matrix(
  c(0,1,2,2,2,2,2,2,2,
    1,0,2,2,2,2,2,2,2,
    2,2,0,1,2,2,2,2,2,
    2,2,1,0,2,2,2,2,2,
    2,2,2,2,0,1,2,2,2,
    2,2,2,2,1,0,2,2,2,
    2,2,2,2,2,2,0,1,1,
    2,2,2,2,2,2,1,0,1,
    2,2,2,2,2,2,1,1,0),
  nrow = 9, ncol = 9, byrow = TRUE,
  dimnames = list(shortlab.partner.child, shortlab.partner.child))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Calculate the dissimilarity matrices with different options to be compared

om.s2.i1<-seqdist(partner.child.year.seq, method = "OM", indel = 1,sm = costs.sm2)
om.s1.i4<-o<-seqdist(partner.child.year.seq, method = "OM", indel = 2,sm = costs.sm1)
om.prop<-seqdist(partner.child.year.seq, method = "OM", indel = 1,sm = prop$sm)
om.theo<-seqdist(partner.child.year.seq, method = "OM", indel = 1,sm = theo)
trate<-seqdist(partner.child.year.seq, method = "OM", indel=1, sm= "TRATE")
lcs<-seqdist(partner.child.year.seq, method = "LCS")
ham<-seqdist(partner.child.year.seq, method = "HAM")
dhd<-seqdist(partner.child.year.seq, method = "DHD")

# Create a data.frame of the various dissimilarity matrices

diss.partner.child <- data.frame(
  OMi1s2 = vech(om.s2.i1),
  OMi2s1 = vech(om.s1.i4),
  prop = vech(om.prop),
  theo = vech(om.theo),
  trate = vech(trate),
  lcs = vech(lcs),
  ham = vech(ham),
  dhd = vech(dhd)
)

# Calculate the correlation between the various dissimilarity matrices

corr.partner.child <- cor(diss.partner.child)

# Display the resulting correlation matrix 

corr.partner.child


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Calculate the normalized dissimilarity matrices with different options to be compared

om.s2.i1.n<-seqdist(partner.child.year.seq, method = "OM", indel = 1,sm = costs.sm2, norm="auto")
om.s1.i4.n<-o<-seqdist(partner.child.year.seq, method = "OM", indel = 2,sm = costs.sm1, norm="auto")
om.prop.n<-seqdist(partner.child.year.seq, method = "OM", indel = 1,sm = prop$sm, norm="auto")
om.theo.n<-seqdist(partner.child.year.seq, method = "OM", indel = 1,sm = theo, norm="auto")
trate.n<-seqdist(partner.child.year.seq, method = "OM", indel=1, sm= "TRATE", norm="auto")
lcs.n<-seqdist(partner.child.year.seq, method = "LCS", norm="auto")
ham.n<-seqdist(partner.child.year.seq, method = "HAM", norm="auto")
dhd.n<-seqdist(partner.child.year.seq, method = "DHD", norm="auto")

# Create a data.frame of the various normalized dissimilarity matrices

diss.partner.child.n <- data.frame(
  OMi1s2 = vech(om.s2.i1.n),
  OMi2s1 = vech(om.s1.i4.n),
  PROP = vech(om.prop.n),
  THEO = vech(om.theo.n),
  TRATE = vech(trate.n),
  LCS = vech(lcs.n),
  HAM = vech(ham.n),
  DHD = vech(dhd.n)
)

# Calculate the correlation between the various dissimilarity matrices

corr.partner.child.n <- cor(diss.partner.child.n)

# Display the resulting correlation matrix 

corr.partner.child.n

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 3.2 - Mantel correlation between normalized dissimilarity matrices ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


cairo_pdf(here("figures", "3-5_Fig3-2_corrDissMatrices_gray.pdf"),
          width=20,
          height=20)

corrplot(corr.partner.child.n, 
         method =("pie"), 
         type = "upper", 
         tl.col = "black", 
         tl.srt = 40, 
         tl.cex	= 2,
         cl.cex	= 2,
         col=brewer.pal(n = 8, name = "Greys"),
         is.corr = FALSE)
dev.off()


pdf_convert(here::here("figures", "3-5_Fig3-2_corrDissMatrices_gray.pdf"),
            format = "png", dpi = 300, pages = 1,
            here::here("figures", "3-5_Fig3-2_corrDissMatrices_gray.png"))



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#save.image(here("data", "R", "yourfinlename.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
