# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))

# load environment generated in "3-0_ChapterSetup.R"
load(here("data", "R", "3-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Defining reference sequences ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Generate a theoretical sequence 

theo.seq<-as.matrix("(S,5)-(MAR,2)-(MARc1,3)-(MARc2+,12)")

# Display the theoretical sequence
theo.seq

# Recode the theoretical sequence from SPS to STS

theo.seq <- seqformat(theo.seq, from = "SPS", to = "STS")

# Define the sequence 

theo.seq<-seqdef(theo.seq, states = shortlab.partner.child,
                 alphabet = shortlab.partner.child, xtstep = 1)

# Dissimilarity between the theoretical sequence and all sequences in the data

dist.theo<-seqdist(partner.child.year.seq, method = "OM", 
                   indel = 1, 
                   sm = "CONSTANT", 
                   refseq = theo.seq)

# Display the dissimilarity values for 3 sequences and the theoretical sequence

dist.theo[1:3] 

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Identify the most frequent sequence in the data

mostfreq.seq<-seqtab(partner.child.year.seq, idxs = 1, weighted = FALSE, format = "SPS")

# Display the most frequent sequence in the data

mostfreq.seq

# Dissimilarity between the most frequent sequence and all sequences in the data

dist.mostfreq<-seqdist(partner.child.year.seq, 
                       method = "OM", 
                       indel = 1, 
                       sm = "CONSTANT", 
                       refseq = mostfreq.seq)

# Display the dissimilarity values for 3 sequences and the most frequent sequence

dist.mostfreq[1:3]

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Identify the medoid sequence in the data

# -- First, compute a dissimilarity matrix
om.s2.i1<-seqdist(partner.child.year.seq, method = "OM", indel = 1, sm = "CONSTANT")

# -- Identify the medoid

medoid.seq <- disscenter(om.s2.i1, medoids.index="first")

# Display the medoid

print(partner.child.year.seq[medoid.seq,], format="SPS")

# Dissimilarity between the medoid and all sequences in the data

dist.medoid<-seqdist(partner.child.year.seq, 
                     method = "OM", 
                     indel = 1, 
                     sm = "CONSTANT", 
                     refseq = medoid.seq[1])

# Display the dissimilarity values for 3 sequences and the medoid

dist.medoid[1:3]

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Figure 3.3 - Reference sequences with illustrative sequences ----
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


cairo_pdf(here("figures", "3-7_Fig3-3_allWithIllustrative_color.pdf"),
          width=10,
          height=12)

layout.fig1 <- layout(matrix(c(1,2,3,4,5), 5, 1, byrow = TRUE),
                      heights = c(.20,.20,.20,.42,.20))
layout.show(layout.fig1)

par(mar=c(3, 3, 3, 2))

#theoretical
seqiplot(theo.seq, 
         with.legend=FALSE,
         border = TRUE, 
         axes = FALSE,
         yaxis = FALSE, ylab = NA,
         main="", 
         cex.main = 2,  
         cpal = colspace.partner.child)
mtext(text = "(a) Theoretical traditional family formation sequence",
      side = 3,#side 1 = bottom
      line = 1,
      las=1)

#most freqent
seqiplot(mostfreq.seq, 
         with.legend=FALSE,
         border = TRUE, 
         axes = FALSE,
         yaxis = FALSE, ylab = NA,
         main="", 
         cex.main = 2,  
         cpal = colspace.partner.child)
mtext(text = "(b) Most frequent family formation sequence in the example data",
      side = 3,#side 1 = bottom
      line = 1,
      las=1)

# medoid
seqiplot(partner.child.year.seq[medoid.seq,], 
         with.legend=FALSE,
         border = TRUE, 
         axes = FALSE,
         yaxis = FALSE, ylab = NA,
         main="", 
         cex.main = 2,  
         cpal = colspace.partner.child)
mtext(text = "(c) Medoid family formation sequence in the example data",
      side = 3,#side 1 = bottom
      line = 1,
      las=1)


#example 3 seq

seqiplot(partner.child.year.seq [1:3, ], 
         with.legend=FALSE,
         border = TRUE, 
         axes = FALSE,
         yaxis = FALSE, ylab = NA,
         main="", 
         cex.main = 2,  
         cpal = colspace.partner.child,
         weighted=FALSE)

par(mgp=c(3,1,-0.5)) # adjust parameters for x-axis
axis(1, at=(seq(0,22, 2)), labels = seq(18,40, by = 2))
par(mgp=c(3,1,0.3), las=1)
axis(2, at=c(0.7,1.9,3), labels = c(1,2,3))
mtext(text = "(d) Three illustrative sequences of family formation",
      side = 3,#side 1 = bottom
      line = 1)
mtext(text = "Age",
      side = 1,#side 1 = bottom
      line = 2)

plot(NULL ,xaxt='n',yaxt='n',bty='n',ylab='',xlab='', xlim=0:1, ylim=0:1)

legend(x = "top",inset = 0, 
       legend = longlab.partner.child, 
       col=colspace.partner.child, 
       lwd=12, 
       cex=1.2, 
       ncol=3,lty = 7)

#legend
par(mar=c(1, 1, 4, 1))

title(main = "", 
      line = 2, font.main = 1)

dev.off()

pdf_convert(here::here("figures", "3-7_Fig3-3_allWithIllustrative_color.pdf"),
            format = "png", dpi = 300, pages = 1,
            here::here("figures", "3-7_Fig3-3_allWithIllustrative_color.png"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#save.image(here("data", "R", "yourfinlename.RData"))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
