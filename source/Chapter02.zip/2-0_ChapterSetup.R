# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~
# Setup ----
# ~~~~~~~~~~

# clear the environment
rm(list = ls())

# use (and install if necessary) here package 
# (is used for referring to file directories)
if (!require("here")) install.packages("here", 
                                       repos = getOption("repos")["CRAN"])
library(here)

# install (if necessary) and load other required packages
source(here("source", "LoadInstallPackages.R"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~
# Import data ----
# ~~~~~~~~~~~~~~~~

# import Stata data set using haven 
family <- read_dta(here("data", "Stata", "PartnerBirthbio.dta"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Extracting and recoding sequence variables ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Note:
  # At the beginning of chapter 2 we are working with a
  # reduced state space which only differentiates partnership
  # states and ignores fertility


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# extracting and recoding the sequence variables (which all start with state)
# recode to reduced state space capturing partnership status only 
seqvars.partner <- family %>%
  select(starts_with("state")) %>%
  mutate_all(~case_when(
    . < 3 ~ 1,            # Single
    . %in% c(3,4) ~ 2,    # LAT
    . %in% c(5,6) ~ 3,    # Cohabiting
    . > 6 ~ 4,))          # Married


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# extracting the sequence variables using the full state space 
# (partner & birth bio)
seqvars.partner.child <- family %>%
  select(starts_with("state"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Define labels for different alphabets ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# reduced state space - partner bio
shortlab.partner <- c("S", "LAT", "COH", "MAR")
longlab.partner <-  c("Single", "LAT", "Cohabiting", "Married")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# full state space - partner & birth bio
shortlab.partner.child <- c("S", "Sc", 
                            "LAT", "LATc", 
                            "COH", "COHc",
                            "MAR", "MARc1", "MARc2+")

# extract labels stored in haven-generated attribute 
# (original data were labelled in Stata)
longlab.partner.child <- names(attributes(seqvars.partner.child$state1)$labels)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Define different color palettes ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Note:
  # The choice of colors is addressed at length in a separate script
  # and also covered on a dedicated page of the companion website


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Color palette for reduced state space
# Set colors using a color palette of the colorspace package
colspace.partner <- sequential_hcl(4, palette = "Heat", rev = TRUE)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Color palette for the full state space (again using colorspace)
col1 <- sequential_hcl(5, palette = "Blues")[3:2]   # Single states
col2 <- sequential_hcl(5, palette = "Greens")[2:1]  # LAT states
col3 <- sequential_hcl(5, palette = "Oranges")[3:2] # Cohabitation states
col4 <- sequential_hcl(5, palette = "magenta")[3:1] # Married states

# Combine to full color palette
colspace.partner.child <- c(col1, col2, col3, col4)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Defining sequence objects ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# monthly data...

# reduced state space (partner bio)
partner.month.seq <- seqdef(seqvars.partner, 
                        states = shortlab.partner, 
                        labels = longlab.partner, alphabet = c(1:4),  
                        cpal = colspace.partner,
                        weights = family$weight40,
                        id = family$id,
                        xtstep = 24)

# full state space (partner & birth bio)
partner.child.month.seq <- seqdef(seqvars.partner.child, 
                            states = shortlab.partner.child,
                            labels = longlab.partner.child, alphabet = c(1:9),  
                            cpal = colspace.partner.child,
                            weights = family$weight40,
                            id = family$id,
                            xtstep = 24)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# change granularity --> years instead of months (using modal values)

# reduced state space (partner bio)
partner.year.seq <- seqgranularity(partner.month.seq, 
                               tspan=12, method="mostfreq")


# full state space (partner & birth bio)
partner.child.year.seq <- seqgranularity(partner.child.month.seq,
                                         tspan=12, method="mostfreq")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# For chapter 2.2: Alternative definition of sequence data
  # Import sequence data from Stata which only consider
  # partnership spells lasting at least 12 months

family2 <- read_dta(here("data", "Stata", "partnerRecodedThreshold12.dta"))

# store sequence variables in a separate object
seqvars2.partner <- family2 %>%
  select(starts_with("state"))

# define sequence object using monthly data
partner.month.seq2 <- seqdef(seqvars2.partner,
                             states = shortlab.partner,
                             labels = longlab.partner, 
                             cpal = colspace.partner,
                             weights = family2$weight40,
                             id = family2$id,
                             xtstep = 24)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Compute standard OM distance matrices for monthly and yearly data ----
# (required for obtaining representative sequences in chapter 2.3.1)
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

partner.month.om <- seqdist(partner.month.seq, 
                            method="OM", sm= "CONSTANT")
partner.year.om <- seqdist(partner.year.seq, 
                           method="OM", sm= "CONSTANT")


# ... and for sequence index plots in chapter 2.3.2
partner.child.month.om <- seqdist(partner.child.month.seq, 
                                  method="OM", sm= "CONSTANT")
partner.child.year.om <- seqdist(partner.child.year.seq, 
                                 method="OM", sm= "CONSTANT")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Save objects for further usage in other scripts ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

save.image(here("data", "R", "2-0_ChapterSetup.RData"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
